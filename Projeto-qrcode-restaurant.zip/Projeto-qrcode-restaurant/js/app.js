ScrollReveal().reveal('', {
  delay: 500
});

// Apply Fluidbox to elements of interest
//$('.card img').fluidbox();